<?php
##  单笔代付
##代码仅供参考

include_once ('./function.php');##引入方法

//生成订单号
$out_trade_no=date('YmdHis').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);

$notifyUrl='https://google.com';
$pageUrl='https://google.com';

$data['bankCode']='UPI';##	银行编码

if($data['bankCode']=="IMPS"){
    $data['province']='test';
}

$data['accName']='test';
$data['accNo']='1234567890';
$data['busiCode']='203001';
$data['currency']='INR';
$data['email']='test@mail.com';
$data['merNo']=$mch_id;
$data['merOrderNo']=$out_trade_no;
$data['notifyUrl']=$notifyUrl;//回调地址 代付成功失败都走回调
$data['orderAmount']='100.00';
$data['phone']='423524127';//限制只能为数字号码
$data['timestamp']=msectime();

$data["sign"]=encrypt($data);//返回加密sign


$data=json_encode($data, JSON_UNESCAPED_UNICODE);
$url='https://taslk.gctpk.com/payout/singleOrder';
$ret=globalpay_http_post_res_json($url,$data);
$ret_arr=json_decode($ret,true);

echo $ret;
