<?php
##  回调通知
##代码仅供参考


//接收数据
$data = file_get_contents("php://input");

//转码
$ret=json_decode($data,true);

//判断订单状态
if($data['status']=='5'){
    //然后进行业务操作

    //最后输出SUCCESS防止多次通知
    echo "SUCCESS";

}