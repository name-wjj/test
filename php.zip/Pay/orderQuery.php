<?php
##代收查询
##代码仅供参考

include_once ('./function.php');##引入方法

//生成请求号
$request_no=date('YmdHis').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);

$data['merNo']=$mch_id;
$data['merOrderNo']='2024031417584048519752';##test order_no
$data['requestNo']=$request_no;
$data['orderNo']='240314000000000022661122';
$data['timestamp']=msectime();
$data['sign']=makeSign($data);

//echo '<pre>';var_dump($data);

$data=json_encode($data, JSON_UNESCAPED_UNICODE);

$url='https://naskl.gctpk.com/payin/orderQuery';
$ret=globalpay_http_post_res_json($url,$data);
$ret_arr=json_decode($ret,true);
echo $ret;
