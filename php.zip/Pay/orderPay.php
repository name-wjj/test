<?php

##代收下单
##代码仅供参考

include_once ('./function.php');##引入方法


//生成订单号
$out_trade_no=date('YmdHis').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);

$notifyUrl='https://google.com';
$pageUrl='https://google.com';
$data['merNo']=$mch_id;
$data['merOrderNo']=$out_trade_no;
$data['name']='test';
$data['email']='test@mail.com';


$data['phone']="9852146882";//限制只能为数字号码
$data['orderAmount']="100.00";
$data['currency']="INR";
$data['busiCode']="103001";##支付编码

$data['notifyUrl']=$notifyUrl;##回调地址
$data['timestamp']=msectime();

$data["sign"]=makeSign($data);

//echo "<pre>";var_dump($data);

$data=json_encode($data, JSON_UNESCAPED_UNICODE);

$url='https://naskl.gctpk.com/payin/createOrder';
$ret=globalpay_http_post_res_json($url,$data);

echo $ret;


