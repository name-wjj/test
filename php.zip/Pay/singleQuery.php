<?php
##单笔代付查询
##代码仅供参考

include_once ('./function.php');##引入方法

//生成请求号
$request_no=date('YmdHis').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);

$data['merNo']=$mch_id;
$data['requestNo']=$request_no;

$data['merOrderNo']='2024031418085897485554';
$data['orderNo']='240314000000000002461740';

$data['timestamp']=msectime();
$data["sign"]=makeSign($data);

$data=json_encode($data, JSON_UNESCAPED_UNICODE);
$url='https://taslk.gctpk.com/payout/singleQuery';
$ret=globalpay_http_post_res_json($url,$data);
$ret_arr=json_decode($ret,true);
echo $ret;