<?php
##基本信息和方法
##代码仅供参考


$mch_id = '商户号';  //商户号替换成自己的
$sha256_key= 'HamcSHA256';  //HamcSHA256密匙替换成自己
$mch_public_key = '商户公钥';  //商户公钥替换自己的
$mch_private_key = '商户私钥';  //商户私钥替换自己的


//生成代付加密签名
function encrypt($data){

    global $mch_private_key;

    //进行HamcSHA256加密
    $signA = makeSign($data);


    //再进行rsa加密
    $encrypted = '';
    $pem = chunk_split($mch_private_key, 64, "\n");
    $pem = "-----BEGIN PRIVATE KEY-----\n" . $pem . "-----END PRIVATE KEY-----\n";
    $private_key = openssl_pkey_get_private($pem);
    openssl_private_encrypt($signA, $encryptData, $private_key);


    //base64编码
    $signB = base64_encode($encryptData);
     return $signB;
}

//请求
function globalpay_http_post_res_json($url, $postData)
{
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/json',
            'content' => $postData,
            'timeout' => 15 * 60 // 超时时间（单位:s）
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return $result;
}

//生成签名
function makeSign($data){
    global $sha256_key;
    ksort($data);
    $str = '';
    foreach ($data as $k => $v){
        if(!empty($v)){
            $str .=(string) $k.'='.$v.'&';
        }
    }
    $str = rtrim($str,'&');
    //HamcSHA256加密
    $sign = hash_hmac("sha256", $str, $sha256_key);

    return $sign;

}

//13位时间戳
function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    return intval($msectime);
}

