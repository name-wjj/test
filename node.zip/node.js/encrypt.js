const { JSEncrypt } = require('./jsencrypt/lib/JSEncrypt')
export default class jsencrypt {
  static privateKey = '私钥'
  static publicKey = '公钥'

  /**
   * rsa 加密方法
   * @param data
   * @returns {*}
   */

  // 加密
  static encrypt(data) {
    return this.encryptRSA(data, this.privateKey)
  }

  static encryptRSA(data, key) {
    const encryptor = new JSEncrypt()
    // 设置私钥
    encryptor.setPrivateKey(key)
    return encryptor.encrypt(data)
  }
  // 解密
  static decrypt(data) {
    return this.decryptRSA(data, this.publicKey)
  }
  static decryptRSA(data, key) {
    const encryptor = new JSEncrypt()
    // 设置公钥
    encryptor.setPublicKey(key)
    return encryptor.decrypt(data)
  }
}
