export declare const Base64: {
    decode(a: string): number[];
    re: RegExp;
    unarmor(a: string): number[];
};
