package com.global.demo;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.global.utils.HttpClient;
import com.global.utils.Md5;
import com.global.utils.StringUtil;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class TestGlo {

    protected static final Logger log = LoggerFactory.getLogger(TestGlo.class);

    private static String key = "";
    private static String mer = "";
    private static String dswg = "";

    private static String dfwg = "";

    private static String priKey = "";
    private static String pubKey = "";


    @Test
    public void payin() {
        JSONObject reqMap = new JSONObject();
        reqMap.put("merNo", mer);
        reqMap.put("merOrderNo", System.currentTimeMillis() + "");
        reqMap.put("orderAmount", "50");
        reqMap.put("currency", "MYR");
        reqMap.put("busiCode", "111002");
        //reqMap.put("pageUrl","https://www.baidu.com");
        reqMap.put("notifyUrl", "http://35.154.224.117:7688/temp/&acqNotify");
        reqMap.put("timestamp", System.currentTimeMillis());
        reqMap.put("bankCode", "");
        reqMap.put("name", "tom");
        reqMap.put("email", "tom@gmail.com");
        reqMap.put("phone", "9001941197");

        String toSign = StringUtil.buildSignSrc(reqMap);
        System.out.println("签名串:" + toSign);
        String sign = HmacSHA256Util.sha256_HMACStr(toSign, key);
        reqMap.put("sign", sign);

        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");

        System.out.println(reqMap);
    }


    @Test
    public void payOut() throws Exception {

        JSONObject reqMap = new JSONObject();
        reqMap.put("merNo", mer);
        reqMap.put("merOrderNo", System.currentTimeMillis() + "");
        reqMap.put("orderAmount", "50");
        reqMap.put("currency", "MYR");
        reqMap.put("busiCode", "211001");
        reqMap.put("province", "SBIN0002169");
        reqMap.put("notifyUrl", "http://35.154.224.117:7688/temp/acqNotify");
        reqMap.put("timestamp", System.currentTimeMillis() + "");
        reqMap.put("bankCode", "MXNSTP");
        reqMap.put("accName", "Noushad Ali");
        reqMap.put("accNo", "32529817673");
        reqMap.put("email", "tom@gmail.com");
        reqMap.put("extend", "tom@gmail.com");
        reqMap.put("phone", "9001941197");

        String toSign = StringUtil.buildSignSrc( reqMap);
        System.out.println("签名串:" + toSign);
        String sign = HmacSHA256Util.sha256_HMACStr(toSign, key);
        System.out.println(sign);
       reqMap.put("sign", RSAPrivateKeyEncryption.encrypt(sign, priKey));

        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");

        System.out.println(reqMap);
        String resMsg = null;
        String url = dfwg+"/payout/singleOrder";
        try {
            resMsg = HttpClient.doPost(url, reqMap.toJSONString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(resMsg);
    }

    @Test
    public void payInOrderQuery() {
        String key = "***************";

        JSONObject reqMap = new JSONObject();
        reqMap.put("merNo", "****************");
        reqMap.put("merOrderNo", "****************");
        reqMap.put("orderNo", "***************");
        reqMap.put("requestNo", System.currentTimeMillis() + "");
        reqMap.put("timestamp", System.currentTimeMillis() + "");

        String toSign = StringUtil.buildSignSrc(reqMap);
        System.out.println("签名串:" + toSign);
        String sign = HmacSHA256Util.sha256_HMACStr(toSign, key);
        reqMap.put("sign", sign);

        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");

        System.out.println(reqMap);
        String resMsg = null;
//        String url = "http://ec2-35-154-224-117.ap-south-1.compute.amazonaws.com:6004/payin/createOrder";
        String url = "http://**************/payin/orderQuery";
        try {
            resMsg = HttpClient.doPost(url, reqMap.toJSONString());
            log.info("响应参数：{}", resMsg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void payOutSingleQuery() {
        String key = "******************";

        JSONObject reqMap = new JSONObject();
        reqMap.put("merNo", "********");
        reqMap.put("merOrderNo", "**************");
        reqMap.put("orderNo", "**************");
        reqMap.put("requestNo", System.currentTimeMillis() + "");
        reqMap.put("timestamp", System.currentTimeMillis() + "");

        String toSign = StringUtil.buildSignSrc(reqMap);
        System.out.println("签名串:" + toSign);
        String sign = HmacSHA256Util.sha256_HMACStr(toSign, key);
        reqMap.put("sign", sign);

        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");

        System.out.println(reqMap);
        String resMsg = null;
//        String url = "http://ec2-35-154-224-117.ap-south-1.compute.amazonaws.com:6004/payin/createOrder";
        String url = "http://47.106.217.72:7601/payout/singleQuery";
        try {
            resMsg = HttpClient.doPost(url, reqMap.toJSONString());
            log.info("响应参数：{}", resMsg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void payOutBalanceQueryQuery() {
        String key = "**********************";

        JSONObject reqMap = new JSONObject();
        reqMap.put("merNo", "*********************");
        reqMap.put("requestNo", System.currentTimeMillis() + "");
        reqMap.put("timestamp", System.currentTimeMillis() + "");

        String toSign = StringUtil.buildSignSrc(reqMap);
        System.out.println("签名串:" + toSign);
        String sign = HmacSHA256Util.sha256_HMACStr(toSign, key);
        reqMap.put("sign", sign);

        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");

        System.out.println(reqMap);
        String resMsg = null;
//        String url = "http://ec2-35-154-224-117.ap-south-1.compute.amazonaws.com:6004/payin/createOrder";
        String url = "http://*************/payout/balanceQuery";
        try {
            resMsg = HttpClient.doPost(url, reqMap.toJSONString());
            System.out.println(resMsg);

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(resMsg);
    }

    @Test
    public void queryCertificate() {
        String key = "*****************";

        JSONObject reqMap = new JSONObject();
        reqMap.put("merNo", "*********************");
        reqMap.put("merOrderNo", "**********");
        reqMap.put("reqTime", DateUtil.getCurrentDate("yyyyMMddHHmmss"));
        reqMap.put("requestNo", System.currentTimeMillis() + "");

        String toSign = StringUtil.buildSignSrc(reqMap);
        System.out.println("签名串:" + toSign);
        String sign = Md5.md5Str(toSign + key);
        reqMap.put("sign", sign);

        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");

        System.out.println(reqMap);
        String resMsg = null;
//        String url = "http://ec2-35-154-224-117.ap-south-1.compute.amazonaws.com:6004/payin/createOrder";
        String url = "http://**************:***/transfer/telegram/api/queryCertificate";
        try {
            resMsg = HttpClient.doPost(url, reqMap.toJSONString());
            log.info("响应参数：{}", resMsg);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test1() throws Exception {
        String asklj = RSAPrivateKeyEncryption.encrypt("asdas",priKey);
        System.out.println(asklj);
        System.out.println(RSAPrivateKeyEncryption.decrypt(asklj,pubKey));
    }


}
